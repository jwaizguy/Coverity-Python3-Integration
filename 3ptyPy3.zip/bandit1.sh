# wrapper to run Bandit on a supplied input source file
# Jose Waizman 3-2020- Based on Ian Ashworth, Aug 2018

#please make sure that the bash shell is pointing to the correct location

# input - supplied filename or a wildcard defn of all matching sources to analyze under the current folder
sourceFileDefn=${1:-*.py}
echo "Usage: bandit1.sh [ single file] i.e. xyz.py  or "
echo "       bandit1.sh   : no args default will pick all *.py files in current folder"

# ------ config ------
# keep our temp files (for debugging)?
keep=0

# define non-zero value for debug output
debugLevel=3

# do not execute the analysis if set to non-zero
dryRun=0


# ----- constants ------
# Bandit toolchain path if not defined in the PATH (if so, set to "")
analysisToolsRoot="/usr/bin/"
analysisTool="bandit"

# Bandit analysis defns - do not change
msgTemplate="file={abspath} line={line}  tag={test_id} subcategory={severity}  function={confidence}  description={msg}"
analysisToolOptions=" -q -f custom --msg-template=\"${msgTemplate}\"  "

BanditDataExt=".bandit"

[ -z "${sourceFileDefn}" ] && echo "ERROR: no source file / definition" && exit 1
dbgTag=""

function dbg 
{
  result=0
  level=${1:-9}
  msg="${2:-No dbg message???}"
  [ ${level} -le ${debugLevel} ] && result=1 && echo "dbg(${level})${dbgTag} - ${msg}"
  return ${result}
}

function BanditThisSource
{
  sourceFile="${1//\\//}"
  outputFile="${sourceFile}${BanditDataExt}"
  # if redirecting output
  redirect="> \"${outputFile}\" 2>&1"

  [ -n "${redirect}" ] && echo "Analysing [${sourceFile}] with Bandit -> [${outputFile}]"

  # call the Bandit toolchain
  cmd="${analysisToolsRoot}${analysisTool} ${analysisToolOptions} \"${sourceFile}\" ${redirect}"
  dbg 2 "cmd = [${cmd}]"
  [ ${dryRun} -eq 0 ] && eval ${cmd}

  [ -n "${redirect}" ] && dbg 1 "See [${outputFile}] for details"
}

[ ${dryRun} -ne 0 ] && echo "NOTE: *DRYRUN* mode is engaged" && dbgTag=" *DR*"
# see if source file defn is a wildcard
wildcardCheck="${sourceFileDefn//[*]/@}"

if  [ "${wildcardCheck}" != "${sourceFileDefn}" ]
then
{

  # loop with wildcard defn
  tempFile="./datafiles.tmp"
  echo "Scanning [${PWD}] for '${sourceFileDefn}' source files ..."
  
  cmd="find . -name '${sourceFileDefn}' > \"${tempFile}\""
  dbg 2 "cmd = [${cmd}]"
  eval ${cmd} 

  records=$(wc -l "${tempFile}" | awk '{print $1}')
  dbg 1 "Python files to analyse [${records}]"
  
  [ ${records} -eq 0 ] && exit 0

  dbg 3  "Preview of the first few records:"
  [ $? -ne 0  ] && cat -n "${tempFile}" | head -10 

  # read list of python source files
  while read thisSourceFile
  do
  {
    # analyse this file 
    BanditThisSource "${thisSourceFile}"
  } done < "${tempFile}"

  [ ${keep} -eq 0 ] && rm -rf "${tempFile}"
}
else
{
  # just the one file to analyse
  BanditThisSource "${sourceFileDefn}"
} fi

dbg 1 "Done"
# end
