#!/usr/bin/bash
echo "usage: bandit2.sh [<int dir> [<project root>] ] or no arguments ( Defaults <int dir> = /idir-Bandit and project root = current directory)"
# Original: Ian Ashworth, Aug 2018
# Modified: Jwaizman 3-31-2020

# import data to this int dir from the project root
intDir="${1:-idir-Bandit}"
projectRoot="${2:-${PWD}}"

# ------ config ------
# keep our temp files (for debugging)
keep=1

# remove the original .Bandit analysis result file if imported OK
removeResult=0

# define non-zero value for debug output
debugLevel=3

# do not execute the "int dir" import of results if set
dryRun=0

#python program name in case program is renamed
Py=python3

# ----- constants ------
# specify where to find the Coverity tools if not in the PATH
covAnalysisInstallRoot="/home/josew/cov-analysis-linux64-2020.03/bin/"

# where to find the Coverity import python3 toolkit scripts called from this script if not in the PATH ( cov-import-Bandit3.py, bandit_import3.py)
covImportToolsRoot="/mnt/c/p3/"

# Bandit data files will bear this hallmark
BanditDataExt=".bandit"

pwd

dbgTag=""

# -----------------------------------------------------------------------
function dbg
{
  result=0
  level=${1:-9}
  msg="${2:-No dbg message???}"
  [ ${level} -le ${debugLevel} ] && result=1 && echo "dbg(${level})${dbgTag} - ${msg}"
  return ${result}
}

function ImportBanditResults
{
  resultFile="$1"
  echo "Importing [${resultFile}]"

  # location of this result (adjacent the source file it analyzed)
  workDir=$(dirname "${resultFile}")
 

  # convert raw Bandit results into a temp Coverity JSON form
  cmd="$Py \"${covImportToolsRoot}Bandit_import3.py\" \"${workDir}\" \"${resultFile}\" > \"${resultFile}.json\""
  dbg 2 "cmd Python = [${cmd}]"
  eval ${cmd}

  # import the JSON data into our intermediary directory
  cmd="${covAnalysisInstallRoot}cov-import-results --dir \"${intDir}\"  -python3 --append \"${resultFile}.json\" --strip-path \"${projectRoot}\""
  dbg 2 "cmd = [${cmd}]"
  [ ${dryRun} -eq 0 ] && eval ${cmd}
  res=$?

  # clean up our own temp JSON file
  [ ${keep} -eq 0 ] && rm -rf "${resultFile}.json"
  return ${res}
}

[ -z "${projectRoot}" ] && echo "ERROR: No build root defined" && exit 2

# temp data file
tempFile="./datafiles.tmp"
[ ${dryRun} -ne 0 ] && echo "NOTE: *DRYRUN* mode is engaged" && removeResult=0;dbgTag=" *DR*"

echo "Scanning [${projectRoot}] for '*${BanditDataExt}' results files ..."
#cmd="find . -name '*${BanditDataExt}' > \"${tempFile}\""
cmd="find \"${projectRoot}\" -name '*${BanditDataExt}' > \"${tempFile}\""
dbg 2 "cmd = [${cmd}]"
eval ${cmd} 

records=$(wc -l "${tempFile}" | awk '{print $1}')
dbg 1 "Bandit result files to process [${records}]"
[ ${records} -eq 0 ] && exit 0

dbg 3 "Preview of the first few records:"
[ $? -ne 0  ] && cat -n "${tempFile}" | head -10 

[ -d "${intDir}" ] && dbg 1 "Adding to existing Coverity int dir [${intDir}]"

# ensure int dir pre-exists
[ ! -d "${intDir}" ] && dbg 1 "Creating new int dir [${intDir}]" && mkdir -p "${intDir}"


# read list of Bandit data files
while read thisDataFile
do
{
  ImportBanditResults "${thisDataFile}"
  res=$?

  # also clean up the Bandit analysis result too, if required
  [ ${keep} -eq 0 -a ${res} -eq 0 -a ${removeResult} -ne 0 ] && rm -rf "${thisDataFile}"

} done < "${tempFile}"

[ ${keep} -eq 0 ] && rm -rf "${tempFile}"

dbg 1 "Done"
#end