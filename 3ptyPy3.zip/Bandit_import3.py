#!python3
from coverity_bandit_import382 import CoverityIssueCollector, get_opts
import re
import os.path
import sys

class BanditCollector(CoverityIssueCollector):
    '''
    A simple collector for bandit  reports.
    The Bandit analysis should be run with the following options:

    -r -f custome
    --msg-template=" {abspath} {line} {test_id} {severity}  {confidence} {msg}"

    In addition, we recommend the following options:

    -q  
    '''

#    _report_re = re.compile(r'^(?P<file>.+?):(?P<line>\d+):\s*\[(?P<subcategory>.+?)\((?P<tag>.+?)\), (?P<function>.*)\] (?P<description>.+)$', re.M)

# for use with Bandit1d.sh wrapper
    _report_re = re.compile(
        r'^file=(?P<file>.+?) line=(?P<line>\d+) tag=(?P<tag>.+?) subcategory=(?P<subcategory>.+?) function=(?P<function>.*) description=(?P<description>.+)$',
        re.M)

    def process(self, f):
        '''
        This method assumes that reports are isolated to a single line.
        If your tool reports issues on multiple lines, or for some other
        reason the report lines may not be reordered, you'll need to
        override this method to handle things appropriately.
        '''

        for l in f:
            l = l.strip()
            if not l: continue

            # Bandit marks the start of a module with a line like **** <module>
			
            if l.startswith('*****'): continue

            m = self._report_re.match(l)
            if m:
                f = m.groupdict()
                msg = self.create_issue(checker = 'Bandit.'+f['tag'],
                            tag = f['tag'],
                            description = f['description'],
                            function = f['function'],
                            subcategory = f['subcategory'])
                msg.add_location(f['line'], f['file'], f['description'])
                self.add_issue(msg)
            else:
                # Bandit inserts code snippets for some issues; skip those lines
                pass
                print ('Unrecognized input format:', l)
                #sys.exit(-1)

if __name__ == '__main__':
    opts = get_opts('Bandit_import382.py', sys.argv)
    print (BanditCollector(**opts).run(sys.argv[-1]))